<?php
declare (strict_types = 1);

namespace app\box\controller;

class Index
{
    public function index()
    {
        return view();
    }
}
