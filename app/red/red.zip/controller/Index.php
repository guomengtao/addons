<?php
declare (strict_types = 1);

namespace app\red\controller;

class Index
{
    public function index()
    {
        return '您好！这是一个[red] 我来覆盖一下';
    }
}
