<?php
declare (strict_types = 1);

namespace app\layui\controller;

class Index
{
    public function index()
    {
        return '您好！这是一个[layui]示例应用,layui和ThinkPHP6的正好功能';
    }
}
